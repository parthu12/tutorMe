/**
 * This example in package <tt>example4</tt> is the most complex in this series
 * of examples. It allows for editing,extending, and persistence. There are,
 * however, many places for improvement. <br>
 * drochowi for CS 321 Fall 2015, 2017
 */
package view.announcement;
