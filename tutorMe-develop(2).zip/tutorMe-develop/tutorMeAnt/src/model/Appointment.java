/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import model.MeetingPlace;
import model.Subject;
import model.Time;

/**
 *
 * @author w1113
 */
public class Appointment {

    /**
     * @param tutor the tutor to set
     */
    public void setTutor(String tutor) {
        this.tutor = tutor;
    }

    /**
     * @param place the place to set
     */
    public void setPlace(MeetingPlace place) {
        this.place = place;
    }

    /**
     * @param subject the subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Time date) {
        this.date = date;
    }

    /**
     * @return the tutor
     */
    public String getTutor() {
        return tutor;
    }

    /**
     * @return the place
     */
    public MeetingPlace getPlace() {
        return place;
    }

    /**
     * @return the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * @return the Date
     */
    public Time getDate() {
        return date;
    }
    private String tutor;
    private MeetingPlace place;
    private String subject;
    private Time date;
    private boolean appointMade;

    /**
     * @return the appointMade
     */
    public boolean isAppointMade() {
        return appointMade;
    }

    /**
     * @param appointMade the appointMade to set
     */
    public void setAppointMade(boolean appointMade) {
        this.appointMade = appointMade;
    }
}
